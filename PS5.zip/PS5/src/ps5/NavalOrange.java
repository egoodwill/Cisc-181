package ps5;

public class NavalOrange extends Orange {
	
	public NavalOrange(double weight){
		super("Orange", weight);
	}
	
	public NavalOrange(String color, double weight){
		super("Orange", weight);
	}
	
	public double getWeight(){
		return weight;
	}
	
	public String getColor(){
		return color;
	}
	
	public double getCalories(){
		return (getWeight() * 5) + ((getWeight() * 5) * .10); 
	}
	
	public boolean equals(Object other){
		if(other instanceof Fruit){
			Fruit obj = (Fruit)other;
			if(obj.getColor() != getColor()){
				return false;
			}
			if(obj.getWeight() != getWeight()){
				return false;
			}
			return true;
		}
		else{
		return false;
		}
	}
}
