package ps5;

public class Snowberry extends Fruit {

	public Snowberry(){
		super("White", 0.117);
	}
	
	public Snowberry(String color, double weight){
		super("White", weight);
	}
	
	public double getWeight(){
		return weight;
	}
	
	public String getColor(){
		return color;
	}
	
	public double getCalories(){
		return 1;
	}

}
