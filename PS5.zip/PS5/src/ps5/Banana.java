package ps5;

public class Banana extends Fruit implements Edible{
		
	public Banana(double weight){
		super("Yellow", weight);
	}
	
	public Banana(String color, double weight){
		super("Yellow", weight);
	}
	
	public double getWeight(){
		return weight;
	}
	
	public String getColor(){
		return color;
	}
	
	public double getCalories(){
		return getWeight() * 10;
	}

}
