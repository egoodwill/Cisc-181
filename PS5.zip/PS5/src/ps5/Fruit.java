package ps5;

public abstract class Fruit {

	protected double weight;
	protected String color;
	
	public Fruit(String color, double weight){
		this.weight = weight;
		this.color = color;
	}
	
	public abstract double getCalories();
	
	public double getWeight(){
		return weight;
	}
	
	public String getColor(){
		return color;
	}
}
