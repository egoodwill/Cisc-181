package ps5;

import java.util.Comparator;

public class CalorieComparator implements Comparator {

	public int compare(Object o1, Object o2) {
		
	}
	
	
}
