package ps5;

public class IceCream implements Edible {
	
	public double getCalories(){
		return 1000.0;
	}
}
