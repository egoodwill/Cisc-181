package ps5;

public interface Edible {
	
	public abstract double getCalories();
}
