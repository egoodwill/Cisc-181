package edu.udel.jatlas.tictactoe5x5;

public class EmptyPiece extends Piece {
    public EmptyPiece() {
        super(' ');
    }
}
