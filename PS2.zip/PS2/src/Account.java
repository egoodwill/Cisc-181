
public class Account {
	private String name;
	private double balance;
	private double interestRate;
	public double limit = 0.0;
	
	// default constructor
	public Account(){
		this("", 0.0, 0.0);
	}
	
	// constructor to support credit 
	public Account(String name, double balance, double interestRate, double limit){
		this.limit = limit;
		this.balance = balance;
		this.name = name;
		this.interestRate = interestRate;
	}
	
	// constructor
	public Account(String name, double balance, double interestRate){
		this.name = name;
		this.balance = balance;
		this.interestRate = interestRate;
	}
	
	// accessor
	public String getName(){
		return name;
	}
	
	// accessor
	public double getBalance(){
		return balance;
	}
	
	// accessor
	public double getInterestrate(){
		return interestRate;
	}
	
	// mutator
	public void deposit(double money){
		this.balance = money + balance;
	}
	
	// mutator
	public boolean withdraw(double money){
		if (balance - money >= limit){
			this.balance = balance - money;
			return true;
		}
		else{
			return false;
		}
	}
	
	// mutator
	public void addMonthlyInterest(){
		this.balance = (balance * interestRate) + balance;
	}
	
	// method to pay off accounts
	public void payoffBalance(Account Payoff){
		if (balance > 0 ){
			if (balance > Math.abs(Payoff.getBalance())){
				withdraw(Math.abs(Payoff.getBalance()));
				Payoff.deposit(Math.abs(Payoff.getBalance()));
			}
			
			else{
				Payoff.deposit(balance);
				withdraw(balance);
			}
		}
	}

}
