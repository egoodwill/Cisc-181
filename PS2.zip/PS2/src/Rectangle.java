
public class Rectangle {
	private double width = 1;
	private double height = 1;
	
	public Rectangle(){
		this(1.0, 1.0);
	}
	
	public Rectangle(double width, double height){
		this.width = width;
		this.height = height;
	}
	// accessor
	public double getArea(){
		return width * height;
	}
	// accessor
	public double getPerimeter(){
		return (2 * width) + (2 * height); 
	}
	// accessor
	public double getHeight(){
		return height;
	}
	// accessor
	public double getWidth(){
		return width;
	}
	
	public static Rectangle makeGoldenRectangle(double longerSide){
		double a = longerSide;
		double shorterSide = (2 * a) / (1 + Math.sqrt(5)) - a;
		return new Rectangle(shorterSide, longerSide);
	}
}
