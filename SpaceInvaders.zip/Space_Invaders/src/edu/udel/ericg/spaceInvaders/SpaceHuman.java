package edu.udel.ericg.spaceInvaders;

import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;

public class SpaceHuman implements OnTouchListener, View.OnKeyListener, View.OnClickListener {
	private SpaceActivity activity;
	
	public SpaceHuman(SpaceActivity activity){
		this.activity = activity;
	}
	
	@Override
	public boolean onKey(View v, int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		return false;
	}
		
	@Override
	public void onClick(View v) {
		SpaceGame game = activity.getCurrentGame();
		if(v instanceof Button){
			Button fire = (Button)v;
			if(activity.getGameType() == 1 && fire.getText().equals("Fire!")){
				game.perform(new Fire());
			}
		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		int action = event.getAction();
		SpaceGame game = activity.getCurrentGame();
        if (game != null) {
            if (game.isEnd()) {
                activity.setAppView("splash");
            }
            else if(activity.getGameType() == 1 && action == MotionEvent.ACTION_DOWN){
                int col = (int)((event.getX() / v.getWidth()) * 
                        game.getColumns());
                SpaceShip ship = game.getShip();
                if(col > ship.getX()){
                	game.perform(new MoveShipRight());
                }
                else{
                	game.perform(new MoveShipLeft());
                }
            }
        }
		return false;
	}
	
}
