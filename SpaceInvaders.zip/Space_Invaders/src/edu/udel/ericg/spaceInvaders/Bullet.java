package edu.udel.ericg.spaceInvaders;

import edu.udel.jatlas.gameframework.Position;

public class Bullet {
	private Position position;
	private boolean alien;
	
	public Bullet(Position position, boolean alien){
		this.position = position;
		this.alien = alien;
	}
	
	public int getX(){
		return position.getColumn();
	}
	
	public int getY(){
		return position.getRow();
	}
	
	public Position getPosition(){
		return position;
	}
	
	public boolean shipContains(SpaceShip ship){
		double bx = getX();
		double by = getY();
		double sx = ship.getX();
		double sy = ship.getY();
		double sw = ship.getWidth();
		double sh = ship.getHeight();
		if(by >= sy - sh && (bx <= sx + sw && bx >= sx - sw)){
			return true;
		}
		else{
			return false;
		}
	}
	
	public boolean alienContains(Alien alien){
		double bx = getX();
		double by = getY();
		double ax = alien.getX();
		double ay = alien.getY();
		double aw = alien.getWidth();
		double ah = alien.getHeight();
		if((by >= ay - ah && by <= ay + ah) && (bx <= ax + aw && bx >= ax - aw)){
			return true;
		}
		else{
			return false;
		}
	}
	
	public void move(){
		if(alien){
			position.setRow(position.getRow() + 1);
		}
		else{
			position.setRow(position.getRow() - 1);
		}
	}
	
	public void onTick(SpaceGame game){
		if(getY() == 17 || getY() == 0){
			position = null;
		}
		else {
			move();
		}
	}
}
