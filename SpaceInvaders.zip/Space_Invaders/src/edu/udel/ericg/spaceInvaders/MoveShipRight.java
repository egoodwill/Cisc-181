package edu.udel.ericg.spaceInvaders;

import edu.udel.jatlas.gameframework.Action;

public class MoveShipRight implements Action<SpaceGame> {
	
	public MoveShipRight(){
	}
	
	public boolean isValid(SpaceGame game) {
		if(game.getShip().getX() == 25){
			return false;
		}
		else{
			return true;
		}
	}

	public void update(SpaceGame game) {
		game.getShip().setX(game.getShip().getX() + 1);
	}
	
}
