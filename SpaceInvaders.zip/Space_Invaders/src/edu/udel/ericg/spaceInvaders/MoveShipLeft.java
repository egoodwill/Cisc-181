package edu.udel.ericg.spaceInvaders;

import edu.udel.jatlas.gameframework.Action;

public class MoveShipLeft implements Action<SpaceGame> {

	public boolean isValid(SpaceGame game) {
		if(game.getShip().getX() == 0){
			return false;
		}
		else{
			return true;
		}
	}

	public void update(SpaceGame game) {
		game.getShip().setX(game.getShip().getX() - 1);
	}

}
