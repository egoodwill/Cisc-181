package edu.udel.ericg.spaceInvaders;


import edu.udel.jatlas.gameframework.Action;
import edu.udel.jatlas.gameframework.Position;

public class Fire implements Action<SpaceGame>{
	
	public Fire(){
	}
	
	public boolean isValid(SpaceGame game) {
		return true;
	}

	public void update(SpaceGame game) {
		Bullet x = new Bullet(new Position(game.getShip().getPosition()), false);
		game.getShipBullets().add(x);
		x.move();
	}

}
