package edu.udel.ericg.spaceInvaders;

import java.util.ArrayList;

import junit.framework.TestCase;

import edu.udel.jatlas.gameframework.Position;


public class SpaceInvaderTests extends TestCase {
	
	public static SpaceGame createStartGame() {
        return SpaceGame.makeDefaultGame();
    }
	
	public static SpaceGame midGame(){
		SpaceShip ship = new SpaceShip(new Position(16, 7));
		ArrayList<Alien> aliens = new ArrayList<Alien>();
		for(int i = 0; i < 3; i++){
			for(int j = 0; j < 7; j++){
				aliens.add(new Alien(new Position(i ,j + 5)));
			}
		}
		ArrayList<Bullet> shipBullets = new ArrayList<Bullet>();
		ArrayList<Bullet> alienBullets = new ArrayList<Bullet>();
		alienBullets.add(new Bullet(new Position(16, 5), true));
		shipBullets.add(new Bullet(new Position(15, 7), false));
		return SpaceGame.makeStartGame(ship, aliens, 1, shipBullets, alienBullets);
	}
	
	public static SpaceGame midGame2(){
		SpaceShip ship = new SpaceShip(new Position(16, 10));
		ArrayList<Alien> aliens = new ArrayList<Alien>();
		for(int i = 0; i < 3; i++){
			for(int j = 0; j < 7; j++){
				aliens.add(new Alien(new Position(i ,j + 5)));
			}
		}
		aliens.remove(15);
		ArrayList<Bullet> shipBullets = new ArrayList<Bullet>();
		ArrayList<Bullet> alienBullets = new ArrayList<Bullet>();
		shipBullets.add(new Bullet(new Position(4, 8), false));
		return SpaceGame.makeStartGame(ship, aliens, 1, shipBullets, alienBullets);
	}
	
	public static SpaceGame endGame(){
		SpaceShip ship = new SpaceShip(new Position(16, 12));
		ArrayList<Alien> aliens = new ArrayList<Alien>();
		for(int i = 0; i < 3; i++){
			for(int j = 0; j < 7; j++){
				aliens.add(new Alien(new Position(i, j)));
			}
		}
		ArrayList<Bullet> shipBullets = new ArrayList<Bullet>();
		ArrayList<Bullet> alienBullets = new ArrayList<Bullet>();
		return new SpaceGame(ship, aliens, 17, 25, 0, 0, shipBullets, alienBullets);
	}
	
	public static SpaceGame endGame2(){
		SpaceShip ship = new SpaceShip(new Position(16, 12));
		ArrayList<Alien> aliens = null;
		ArrayList<Bullet> shipBullets = new ArrayList<Bullet>();
		ArrayList<Bullet> alienBullets = new ArrayList<Bullet>();
		return SpaceGame.makeStartGame(ship, aliens, 1, shipBullets, alienBullets);
	}
	
	public void test_isEnd(){
		assertFalse(createStartGame().isEnd());
		assertFalse(midGame2().isEnd());
		assertTrue(endGame().isEnd());
	}
	
	public void test_shipContains(){
		SpaceGame game = midGame();
		Bullet bullet = new Bullet(new Position(game.getShip().getX(), game.getShip().getY()), true);
		game.getAlienBullets().add(bullet);
		assertFalse(game.getAlienBullets().get(0).shipContains(game.getShip()));
		assertTrue(game.getAlienBullets().get(1).shipContains(game.getShip()));
	}
	
	public void test_MoveShipRight(){
		MoveShipRight x = new MoveShipRight();
		assertTrue(x.isValid(createStartGame()));
		assertTrue(x.isValid(endGame()));
		assertTrue(x.isValid(midGame()));
		
		SpaceGame game = createStartGame();
		x.update(game);
		assertEquals(17, game.getShip().getX());
	}
	
	public void test_MoveShipLeft(){
		MoveShipLeft x = new MoveShipLeft();
		assertTrue(x.isValid(createStartGame()));
		assertTrue(x.isValid(endGame()));
		assertTrue(x.isValid(midGame()));
		
		SpaceGame game = createStartGame();
		x.update(game);
		assertEquals(15, game.getShip().getX());
	}
	
	public void test_livesLost(){
		SpaceGame game = midGame();
		Bullet bullet = new Bullet(new Position(16,7), true);
		game.getAlienBullets().add(bullet);
		assertEquals(2, game.getLives());
	}
	
	public void test_Fire(){
		Fire y = new Fire();
		assertTrue(y.isValid(createStartGame()));
		assertTrue(y.isValid(endGame()));
		assertTrue(y.isValid(midGame()));
		
		SpaceGame game = createStartGame();
		y.update(game);
		assertEquals(15, game.getShipBullets().get(0).getY());
	}
	
	public void test_onTick(){
		SpaceGame game = midGame();
		Bullet bullet = new Bullet(new Position(16, 6), true);
		game.getAlienBullets().add(bullet);
		game.onTick();
		
		assertEquals(2, game.getLives());
		assertEquals(1, game.getAliens().get(0).getX());
	}
	
	public void test_getHeuristic(){
		ShipAI AI = new ShipAI();
		SpaceGame game = midGame();
		SpaceGame game2 = midGame();
		Bullet bullet1 = new Bullet(new Position(game.getShip().getX() - 1, game.getShip().getY() - 1)
		, true);
		Bullet bullet2 = new Bullet(new Position(game2.getShip().getX() + 1, game2.getShip().getY() - 1)
		, true);
		game.getAlienBullets().add(bullet1);
		game2.getAlienBullets().add(bullet2);
		MoveShipRight right = new MoveShipRight();
		MoveShipLeft left = new MoveShipLeft();
		
		assertEquals(0.0, AI.getHeuristicScore(null, endGame()));
		assertEquals(-1.0, AI.getHeuristicScore(left, game));
		assertEquals(1.0, AI.getHeuristicScore(right, game2));
	}
		
	public static void main(String[] args){
		System.out.println(createStartGame());
		System.out.println(midGame());
		System.out.println(midGame2());
		System.out.println(endGame());
		System.out.println(endGame2());
		SpaceGame game = midGame();
		game.onTick();
		System.out.println(game);
		}
}
