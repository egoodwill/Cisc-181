package edu.udel.ericg.spaceInvaders;

import edu.udel.jatlas.gameframework.Position;

public class SpaceShip {
	private Position position;
	private int lives;
	private int width;
	private int height;
	
	public SpaceShip(Position position){
		this.position = position;
	}

	public Position getPosition(){
		return position;
	}
	
	public int getWidth(){
		return width;
	}
	
	public int getLives(){
		return lives;
	}
	
	public int getHeight(){
		return height;
	}

	public int getX(){
		return position.getColumn();
	}
	
	public int getY(){
		return position.getRow();
	}
	
	public void setX(int start){
		position.setColumn(start);
	}
	
	public void setY(int start){
		position.setRow(start);
	}

}
