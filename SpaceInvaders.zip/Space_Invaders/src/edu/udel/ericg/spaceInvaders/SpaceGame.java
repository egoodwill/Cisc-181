package edu.udel.ericg.spaceInvaders;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import edu.udel.jatlas.gameframework.ConsoleListener;
import edu.udel.jatlas.gameframework.Game;
import edu.udel.jatlas.gameframework.JavaTicker;
import edu.udel.jatlas.gameframework.Position;

public class SpaceGame extends Game {
	
	public static final int WORLD_WIDTH = 25;
	public static final int WORLD_HEIGHT = 17;
	public static final int SHIP_START_X = 16;
	public static final int SHIP_START_Y = 16;
	
	private ArrayList<Alien> aliens;
	private SpaceShip ship;
	private int rows;
	private int columns;
	private int level;
	private int lives;
	private ArrayList<Bullet> alienBullets;
	private ArrayList<Bullet> shipBullets;
	
	public SpaceGame(SpaceShip ship, ArrayList<Alien> aliens, int rows, int columns, int level, int lives, 
			 ArrayList<Bullet> shipBullets, ArrayList<Bullet> alienBullets){
		this.ship = ship;
		this.aliens = aliens;
		this.rows = rows;
		this.columns = columns;
		this.level = level;
		this.lives = lives;
		this.shipBullets = shipBullets;
		this.alienBullets = alienBullets;
	}
	
	public static SpaceShip makeStartShip(){
		return new SpaceShip(new Position(SHIP_START_X, SHIP_START_Y));
	}
	
	public static ArrayList<Alien> makeStartAliens(){
		ArrayList<Alien> aliens = new ArrayList<Alien>();
		for(int i = 0; i <= 3; i++){
			for(int j = 0; j <= 7; j++){
				aliens.add(new Alien(new Position(j, i)));
			}
		}
		return aliens;
		
	}

	public ArrayList<Bullet> alienBullets(){
		ArrayList<Bullet> alienBullets = new ArrayList<Bullet>();
		for(Alien alien : getAliens()){
			alienBullets.add(new Bullet(new Position(alien.getPosition()), true));
		}
		return alienBullets;
	}
	
	public void setLevel(int level){
		this.level = level;
	}
	
	public ArrayList<Bullet> getAlienBullets(){
		return alienBullets;
	}
	
	public ArrayList<Bullet> getShipBullets(){
		return shipBullets;
	}
	
	public int getRows(){
		return rows;
	}
	
	public int getColumns(){
		return columns;
	}
	
	public int getLevel(){
		return level;
	}
	
	public int getLives(){
		return lives;
	}
	
	public SpaceShip getShip(){
		return ship;
	}
	
	public ArrayList<Alien> getAliens(){
		return aliens;
	}
	
	public void nextLvl(){
		setLevel(getLevel() + 1);
		for(int i = 0; i <= 3; i++){
			for(int j = 0; j <= 7; j++){
				aliens.add(new Alien(new Position(j, i)));
			}
		}
		lives++;
		for(Alien aliens : getAliens()){
			aliens.changeHealthUp();
		}
	}
	
	public String toString(){
		char[][] grid = new char[rows][columns];
		for(char[] row : grid){
			Arrays.fill(row, ' ');
		}
		for(Bullet bullet : alienBullets){
			grid[bullet.getX()][bullet.getY()] = 'v';
		}
		for(Bullet bullet : shipBullets){
			grid[bullet.getX()][bullet.getY()] = '^';
		}
		if(aliens != null){
		for(Alien alien : aliens){
                grid[alien.getX()][alien.getY()] = 'A';
			}
		}
		int sx = ship.getX();
		int sy = ship.getY();
		grid[sx][sy] = 'S';
		StringBuilder buffer = new StringBuilder();
		buffer.append(getStatus()).append('\n');
        for (char[] row : grid) {
            buffer.append(row);
            buffer.append('\n');
        }
        return buffer.toString();
	}
	
	public String getStatus() {
        return "Level " + getLevel() + "  Lives " + getLives();
	}
	
	public void alienFire(){
		for(Bullet bullet : alienBullets){
			if(bullet.getY() + 1 <= 17){
				bullet.move();
			}
			else{
				bullet = null;
			}
		}
	}
	
	public int livesLost(){
		Iterator<Bullet> bulletIter = alienBullets.iterator();
		while(bulletIter.hasNext()){
			Bullet bullet = bulletIter.next();
			if(bullet.shipContains(ship)){
				lives--;
				bulletIter.remove();
			}
		}
		for(Alien alien : aliens){
			if(alien.getPosition().blockDistance(ship.getPosition()) == 0){
				lives = 0;
			}
		}
		return lives;
	}
	
	public ArrayList<Alien> deadAliens(){
		Iterator<Bullet> bullIter = shipBullets.iterator();
		while (bullIter.hasNext()){
			Bullet bullet = bullIter.next();
			Iterator<Alien> alienIter = aliens.iterator();
			while (alienIter.hasNext()) {
				Alien alien = alienIter.next();
				if(bullet.alienContains(alien)){
					alien.changeHealthDown();
					bullIter.remove();
					if(alien.getHealth() == 0){
						alienIter.remove();
					}
					break;
				}
			}
		}
		return aliens;
	}
	
	public void onTick(){
		for(Alien alien : getAliens()){
			alien.onTick(this);
		}
		Iterator<Bullet> bulletIter = getAlienBullets().iterator();
		while(bulletIter.hasNext()) {
			Bullet bullet = bulletIter.next();
			bullet.onTick(this);
			if (bullet.getPosition() == null) {
				bulletIter.remove();
			}
		}
		Iterator<Bullet> bulletIter1 = getShipBullets().iterator();
		while(bulletIter1.hasNext()) {
			Bullet bullet = bulletIter1.next();
			bullet.onTick(this);
			if (bullet.getPosition() == null) {
				bulletIter1.remove();
			}
		}
		livesLost();
		deadAliens();
		///....................
		if(getAliens().size() == 0){
//			makeDefaultGame();
			nextLvl();
		}
		for(Alien alien : getAliens()){
			if (Math.random() < 0.02) {
				Bullet bullet = new Bullet(new Position(alien.getPosition()), true);
				getAlienBullets().add(bullet);
				alienFire();
			}
		}
	}
	
	public boolean isEnd(){ 
		for (Alien a : getAliens()) {
			if (a.getPosition().getRow() == 16) {
				return true;
			}
		}
		if(lives == 0){
			return true;
		}
		else{
			return false;
		}
	}
	
	public static SpaceGame makeDefaultGame(){
		SpaceShip ship = makeStartShip();
		int level = 1;
		ArrayList<Alien> aliens = makeStartAliens();
		ArrayList<Bullet> shipBullets = new ArrayList<Bullet>();
		ArrayList<Bullet> alienBullets = new ArrayList<Bullet>();
		return makeStartGame(ship, aliens, level, shipBullets, alienBullets);
	}
	
	public static SpaceGame makeStartGame(SpaceShip ship, ArrayList<Alien> aliens, int level,
		ArrayList<Bullet> shipBullets, ArrayList<Bullet> alienBullets) {
        return new SpaceGame(ship, aliens, WORLD_HEIGHT, WORLD_WIDTH, level, 3, shipBullets, alienBullets);
    }
	

    public static void main(String[] args) {
        SpaceGame game = makeDefaultGame();
        game.addGameListener(new ConsoleListener());
        game.addGameListener(new ShipAI());
        game.start(new JavaTicker());
    }
}
