package edu.udel.ericg.spaceInvaders;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class SpaceScreen extends LinearLayout implements View.OnClickListener {
	
	private SpaceActivity activity;
    
    private ImageView imageView;
    private Bitmap splashImage;
    private Button[] buttons;
        
    
    public SpaceScreen(SpaceActivity activity) {
        super(activity);
        this.activity = activity;
        this.imageView = new ImageView(activity);
        this.buttons = new Button[3];
        for (int i = 0; i < 3; i++) {
            buttons[i] = new Button(activity);
        }
        
        splashImage = BitmapFactory.decodeResource(activity.getResources(), 
            activity.getResources().getIdentifier("splashscreen", "drawable", getClass().getPackage().getName()));
        
        init();
    }
    
    private void init() {
        setOrientation(LinearLayout.VERTICAL);
        
        imageView.setImageBitmap(splashImage);
        imageView.setAdjustViewBounds(true);
        
 
        buttons[0].setText("Play Game");
        buttons[1].setText("Demo");
        buttons[2].setText("Quit");
        
        for (Button button: buttons) {
            button.setTypeface(Typeface.SANS_SERIF);
            button.setGravity(Gravity.CENTER);
            button.setBackgroundColor(Color.BLUE);
            button.setTextColor(Color.WHITE);
            button.setOnClickListener(this);
            button.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,
                LayoutParams.WRAP_CONTENT));
        }
        
        imageView.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT));
       


        addView(imageView);
        for (Button button: buttons) {
            addView(button);
        }
    }

	@Override
	public void onClick(View v) {
		if (v instanceof Button) {
            Button b = (Button)v;
            activity.selectMenuOption(b.getText());
		}
	}
	
 }
