package edu.udel.ericg.spaceInvaders;

import java.util.ArrayList;

import edu.udel.jatlas.gameframework.Position;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class SpaceView extends View {
	protected SpaceActivity activity;
	
	private Bitmap alienImage;
    private Bitmap shipImage;
	
	public SpaceView(SpaceActivity context) {
		super(context);
		activity = context;
		
		setBackgroundColor(Color.BLACK);
		
		setFocusable(true);
		setFocusableInTouchMode(true);
		shipImage = loadImage("ship");
        alienImage = loadImage("alien");
	}
	
	private Bitmap loadImage(String name) {
        return BitmapFactory.decodeResource(activity.getResources(), 
            activity.getResources().getIdentifier(name, "drawable", getClass().getPackage().getName()));
    }
	
	protected void onDraw(Canvas canvas){
		super.onDraw(canvas);
		
		canvas.save();
        canvas.scale(
            getWidth() / (float)SpaceGame.WORLD_WIDTH, 
            getHeight() / (float)SpaceGame.WORLD_HEIGHT);
        
        drawAliens(canvas);
        drawShip(canvas);
        drawAlienBullets(canvas);
        drawShipBullets(canvas);
        
        
        canvas.restore();
	}
	
	RectF rectF = new RectF();
	private void setRectFromPosition(Position position) {
        rectF.set(position.getColumn(), position.getRow(), position.getColumn()+1f, position.getRow()+1f);
    }
	
	public void drawAliens(Canvas canvas){
		ArrayList<Alien> aliens = activity.getCurrentGame().getAliens();
    	for(Alien alien : aliens){
    		Position position = alien.getPosition();
    		setRectFromPosition(position);
    		canvas.drawBitmap(alienImage, null, rectF, null);
    	}
	}
	
	public void drawShip(Canvas canvas){
    	SpaceShip ship = activity.getCurrentGame().getShip();
    	Position position = ship.getPosition();
    	setRectFromPosition(position);
    	canvas.drawBitmap(shipImage, null, rectF, null);
	}
	
	public void drawShipBullets(Canvas canvas){
		Paint paint3 = new Paint();
		paint3.setColor(Color.GREEN);
		paint3.setStrokeWidth(.1f);
		ArrayList<Bullet> bullets = activity.getCurrentGame().getShipBullets();
		for(Bullet bullet : bullets){
			canvas.drawCircle(bullet.getX(), bullet.getY(), .1f, paint3);
		}
	}
	
	public void drawAlienBullets(Canvas canvas){
		Paint paint4 = new Paint();
		paint4.setColor(Color.RED);
		paint4.setStrokeWidth(.1f);
		ArrayList<Bullet> bullets = activity.getCurrentGame().getAlienBullets();
		for(Bullet bullet : bullets){
			System.out.println(bullet.toString() + " at " + bullet.getPosition());
			
			canvas.drawCircle(bullet.getX(), bullet.getY(), .1f, paint4);
		}
	}
}
