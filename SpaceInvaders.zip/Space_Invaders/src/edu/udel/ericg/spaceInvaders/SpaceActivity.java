package edu.udel.ericg.spaceInvaders;

import java.util.HashMap;
import java.util.Map;

import edu.udel.jatlas.gameframework.Action;
import edu.udel.jatlas.gameframework.GameListener;
import edu.udel.jatlas.gameframework.android.AndroidTicker;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SpaceActivity extends Activity implements GameListener<SpaceGame> {
	public static final int GAMETYPE_AI = 0;
	public static final int GAMETYPE_PLAYER = 1;
	
	private SpaceView gameView;
	private SpaceGame game;
	private TextView status;
	private Map<String, View> appView;
	private Button fire;
	
	private int gameType;
	
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		appView = new HashMap<String, View>();
		status = new TextView(this);
		gameView = new SpaceView(this);
		
		LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.addView(status);
    
        LinearLayout buttonLayout = new LinearLayout(this);
        fire = new Button(this);
        fire.setText("Fire!");
        
        fire.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT,
                0.25f));
        fire.setBackgroundColor(Color.TRANSPARENT);
        fire.setTextColor(Color.WHITE);
        buttonLayout.addView(fire);
        
        FrameLayout fl = new FrameLayout(this);
        fl.addView(gameView);
        LinearLayout hidden = new LinearLayout(this);
        hidden.setOrientation(LinearLayout.VERTICAL);
        View hiddenView = new View(this);
        hiddenView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT,
            2.0f));
        hidden.addView(hiddenView);
        hidden.addView(buttonLayout);
        buttonLayout.setLayoutParams(new LinearLayout.LayoutParams(
          LinearLayout.LayoutParams.MATCH_PARENT,
          LinearLayout.LayoutParams.MATCH_PARENT,
          0.2f));
        fl.addView(hidden);
        
        ll.addView(fl);
        
        appView.put("Game", ll);
        appView.put("Splash", new SpaceScreen(this));
        

        setAppView("Splash");
	}
	
	public SpaceGame getCurrentGame(){
		return game;
	}
	
	public int getGameType(){
		return gameType;
	}
	
	public void startGame(){
		game = SpaceGame.makeDefaultGame();
        game.addGameListener(this);

        game.setRealTimeTickLength(200);
        if (gameType == GAMETYPE_AI) {
            game.addGameListener(new ShipAI());
        }
        SpaceHuman human = new SpaceHuman(this);
        gameView.setOnTouchListener(human);
        gameView.setOnKeyListener(human);
        fire.setOnClickListener(human);
        
        game.start(new AndroidTicker());
        setAppView("Game");
        
	}
	
	void setAppView(String nameview) {
		View view = appView.get(nameview);
        setContentView(view);
        view.invalidate();
	}

	public void restart(){
		if(game != null){
			game.end();
		}
		startGame();
	}
	
	

	public void onPerformActionEvent(Action<SpaceGame> action, SpaceGame game) {
		updateViews();
		
	}

	@Override
	public void onTickEvent(SpaceGame game) {
		updateViews();
		
	}

	@Override
	public void onStartEvent(SpaceGame game) {
		updateViews();
		
	}

	@Override
	public void onEndEvent(SpaceGame game) {
		updateViews();
		
	}

	@Override
	public void onEvent(String event, SpaceGame game) {
		updateViews();
		
	}
	
	private void updateViews(){
		gameView.invalidate();
		status.setText(game.getStatus());
	}
	
	public boolean onCreateOptionsMenu(Menu menu){
		menu.add("Play Game");
		menu.add("Demo");
		menu.add("Restart");
		menu.add("Quit");
		return true;
	}
	
	public boolean onOptionsItemSelected(MenuItem item){
		 CharSequence title = item.getTitle();
	        if (title.equals("Demo")) {
	            gameType = GAMETYPE_AI;
	            restart();
	        }
	        else if (title.equals("Play Game")) {
	            gameType = GAMETYPE_PLAYER;
	            restart();
	        }
	        else if (title.equals("Restart")) {
	            restart();
	        }
	        else if (title.equals("Quit")) {
	            setAppView("Splash");
	        }
	        return true;
	        
	    }

	public void selectMenuOption(CharSequence text) {
		if(text.equals("Demo")){
			gameType = 0;
			restart();
		}
		else if(text.equals("Play Game")){
			gameType = 1;
			restart();
		}
		else if(text.equals("Restart")){
			restart();
		}
		else if(text.equals("Quit")){
			finish();
		}
		
	}

}
