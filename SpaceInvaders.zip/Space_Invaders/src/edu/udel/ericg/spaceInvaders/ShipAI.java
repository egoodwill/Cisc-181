package edu.udel.ericg.spaceInvaders;

import java.util.ArrayList;
import java.util.List;

import edu.udel.jatlas.gameframework.AI;
import edu.udel.jatlas.gameframework.Action;

public class ShipAI extends AI<SpaceGame> {

	public ShipAI() {
		super("AI");
	}

	public List<Action<SpaceGame>> getAllValidActions(SpaceGame game) {
		 List<Action<SpaceGame>> validMoves = new ArrayList<Action<SpaceGame>>();
	        if (!game.isEnd()) {
	        	validMoves.add(new Fire());
	        	validMoves.add(new MoveShipLeft());
	        	validMoves.add(new MoveShipRight());
	        }
	        return validMoves;
	}

	public double getHeuristicScore(Action<SpaceGame> action, SpaceGame game) {
		if (game.isEnd()) {
            return 0;
		}
		
		SpaceShip ship = game.getShip();
		for(Bullet bullet : game.getAlienBullets()){
			if(bullet.getX() == ship.getX() - 1 && bullet.getY() == ship.getY() - 1){
				return -1;
			}
			if(bullet.getX() == ship.getX() + 1 && bullet.getY() == ship.getY() - 1){
				return 1;
			}
		}
		return 2;
	}
}

