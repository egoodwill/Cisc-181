package edu.udel.ericg.spaceInvaders;

import edu.udel.jatlas.gameframework.Position;

public class Alien {
	private Position position;
	private int height;
	private int width;
	private int originalState;
	private int health = 1;
	
	public Alien(Position position){
		this.position = position;
	}
	
	public int getHealth(){
		return health;
	}
	
	public void changeHealthUp(){
		health = health + 1;
	}
	
	public void changeHealthDown(){
		health = health - 1;
	}
	
	public Position getPosition(){
		return position;
	}
	
	public int getOrignalState(){
		return originalState;
	}
	
	public int getX(){
		return position.getColumn();
	}
	
	public int getY(){
		return position.getRow();
	}
	
	public double getHeight(){
		return height;
	}
	
	public double getWidth(){
		return width;
	}
	
	public void setX(int d){
		position.setColumn(d);
	}
	
	public void setY(int x){
		position.setRow(x);
	}
	
	public void onTick(SpaceGame game){
		if(getY() % 2 != originalState % 2 || originalState < 0 ){
			setX(getX() + 1);
			if(getX() == 26){
				setY(getY() + 1);
				setX(getX() - 1);
			}
			
		}
		else{
			setX(getX() - 1);
			if(getX() == -1){
				setY(getY() + 1);
				setX(getX() + 1);
			}
			
		}
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return position.toString();
	}

}
