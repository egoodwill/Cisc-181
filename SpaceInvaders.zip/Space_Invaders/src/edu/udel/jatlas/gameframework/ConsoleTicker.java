package edu.udel.jatlas.gameframework;

public class ConsoleTicker {

}
