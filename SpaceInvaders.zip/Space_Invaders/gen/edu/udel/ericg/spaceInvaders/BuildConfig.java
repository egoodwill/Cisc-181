/** Automatically generated file. DO NOT MODIFY */
package edu.udel.ericg.spaceInvaders;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}