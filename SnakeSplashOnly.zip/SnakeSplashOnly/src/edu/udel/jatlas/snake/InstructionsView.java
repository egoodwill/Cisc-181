package edu.udel.jatlas.snake;

import android.view.MotionEvent;
import android.widget.LinearLayout;
import android.widget.TextView;

public class InstructionsView extends LinearLayout {
    private SnakeActivity activity;
    public InstructionsView(SnakeActivity activity) {
        super(activity);
        this.activity = activity;
        
        TextView instructionText = new TextView(activity);
        instructionText.setText("Tap the screen to move the snake or press the directional keys.\n"+
                "Eat the food and avoid walls and don't eat your own tail!");
        addView(instructionText);
    }
    
    public boolean onTouchEvent(MotionEvent event) {
        activity.setAppView("Menu");
        return false;
    }
}
