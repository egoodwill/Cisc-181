package edu.udel.jatlas.tictactoe5x5;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import edu.jatlas.gameframework.android.AndroidTicker;
import edu.udel.jatlas.gameframework.Action;
import edu.udel.jatlas.gameframework.Game;
import edu.udel.jatlas.gameframework.GameListener;
import	android.app.Activity;
import android.graphics.Typeface;
import	android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import	android.widget.TextView;
public class TicTacToe5x5Activity extends Activity implements GameListener<TicTacToe5x5Game> {
				
	protected TicTacToe5x5Game game;
	protected TextView status;
	protected TicTacToe5x5View2D gameView;
	protected LinearLayout layout;
	private static final int GAMETYPE_HUMAN_AI = 0;
	private static final int GAMETYPE_HUMAN_HUMAN = 1;
	private static final int GAMETYPE_AI_AI = 2;
	
	private int gameType;
	
	
				public TicTacToe5x5Game getCurrentGame(){
					return game;
				}
				
				protected void updateViews(TicTacToe5x5Game game){
					status.setText(game.getStatus());
					gameView.invalidate();
				}
				
				protected void	onCreate(Bundle	savedInstanceState)	{
					super.onCreate(savedInstanceState);
					gameView = new TicTacToe5x5View2D(this);
					status = new TextView(this);
					status.setTypeface(Typeface.MONOSPACE);
					startGame();
					layout = new LinearLayout(this);
					layout.setOrientation(LinearLayout.VERTICAL);
					layout.addView(gameView);
					layout.addView(status);
					setContentView(layout);
				}
				
				private void startGame(){
					game = TicTacToe5x5Game.makeStartGame('x', 'o');
					if(Math.random() > 0.5){
						game.changeTurn();
					}
					game.addGameListener(this);
					List<Character> humanPlayers = new ArrayList<Character>();
					if(gameType == GAMETYPE_HUMAN_HUMAN || gameType == GAMETYPE_HUMAN_AI){
						humanPlayers.add('x');
					}
					else{
						game.addGameListener(new TicTacToe5x5AI("x"));
					}
					if(gameType == GAMETYPE_AI_AI || gameType == GAMETYPE_HUMAN_AI){
						game.addGameListener(new TicTacToe5x5AI("o"));
					}
					else{
						humanPlayers.add('o');
					}
					
					game.start(new AndroidTicker());
					gameView.setOnTouchListener(new TicTacToe5x5Human(this,
							new HashSet<Character>(humanPlayers)));
				}
				
				public void restartGame(){
					if(game!= null && game.getLifecycle() != Game.ENDED){
						game.end();
					}
					startGame();
				}

				@Override
				public void onPerformActionEvent(
						Action<TicTacToe5x5Game> action, TicTacToe5x5Game game) {
					updateViews(game);
					
				}

				@Override
				public void onTickEvent(TicTacToe5x5Game game) {
					
					
				}

				@Override
				public void onStartEvent(TicTacToe5x5Game game) {
					updateViews(game);
					
				}

				@Override
				public void onEndEvent(TicTacToe5x5Game game) {
					updateViews(game);
					
				}

				@Override
				public void onEvent(String event, TicTacToe5x5Game game) {
					
					
				}
				
				public boolean onCreateOptionsMenu(Menu menu){
					menu.add("AI Game");
					menu.add("1Player Game");
					menu.add("2Player Game");
					menu.add("Restart");
					menu.add("Quit");
					return true;
				}
				
				public boolean onOptionsItemSelected(MenuItem item) {
			        String value = item.getTitle().toString();
			        if(value.equals("AI Game")){
			        	gameType = 2;
			        	restartGame();
			        }
			        
			        if(value.equals("1Player Game")){
			        	gameType = 0;
			        	restartGame();
			        }
			        
			        if(value.equals("2Player Game")){
			        	gameType = 1;
			        	restartGame();
			        }
			        
			        if(value.equals("Restart")){
			        	restartGame();
			        }
			        
			        if(value.equals("Quit")){
			        	finish();
			        }
			        return true;
				}
				
}
