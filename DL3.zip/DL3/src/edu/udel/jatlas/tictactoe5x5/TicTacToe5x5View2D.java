package edu.udel.jatlas.tictactoe5x5;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.view.View;

/**
 * This view extends the basic android.view.View to provide implementations for
 * drawing directly to the Canvas.
 * 
 * @author jatlas
 *
 */
public class TicTacToe5x5View2D extends View {
    // the activity
    protected TicTacToe5x5Activity activity;
    
    public TicTacToe5x5View2D(TicTacToe5x5Activity context) {
        super(context);
        activity = context;
        setBackgroundColor(Color.BLACK);
        setFocusable(true);
        setFocusableInTouchMode(true);
    }
    
    /**
     * Provides specific implementation for a TicTacToe5x5View.  This view has 3 main components:
     *   - a grid
     *   - a set of pieces
     */
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // set the canvas so that it scales the screen to our world coordinates
        // our tic tac toe world is 5 x 5
        canvas.save();
        canvas.scale(getWidth() / 5f, getHeight() / 5f);

        // draw our world
        drawGrid(canvas);
        drawPieces(canvas);
        
        // set the canvas scaling back (this is necessary)
        canvas.restore();
    }

    private void drawPieces(Canvas canvas) {
    	Paint paint1 = new Paint();
    	paint1.setColor(Color.RED);
    	paint1.setStrokeWidth(.1f);
    	Paint paint2 = new Paint();
    	paint2.setColor(Color.GREEN);
    	paint2.setStrokeWidth(.1f);
    	Piece[][] board  = activity.getCurrentGame().getBoard();
		for(int i = 0; i < board.length; i++){
			for(int j = 0; j < board[i].length; j++){
				if(board[i][j].getSymbol() == 'o'){
					canvas.drawCircle((float)j + 0.5f, (float)i + .5f, (float).5, paint1);
				}
				if(board[i][j].getSymbol() == 'x'){
					canvas.drawLine((float)j, (float)i, (float)j + 1, (float)i + 1, paint2);
					canvas.drawLine((float)j, (float)i + 1, (float)j + 1, (float)i, paint2);
				}
			}
		}
		
	}

	/**
     * Draws a 5x5 grid with the middle square filled in.
     * 
     * @param canvas
     */
    protected void drawGrid(Canvas canvas) {
        Paint gridPaint = new Paint();
        gridPaint.setColor(Color.WHITE);
        gridPaint.setStrokeWidth(.05f); // the "weight" of the lines
        gridPaint.setStyle(Style.FILL_AND_STROKE);
        
        // draw horizontal lines for each row
        Piece[][] board = activity.getCurrentGame().getBoard();
        for (int i = 0; i <= board.length; i++) {
            canvas.drawLine(0, i, 5, i, gridPaint);
        }
        // draw vertical lines for each row
        for (int i = 0; i <= board.length; i++) {
            canvas.drawLine(i, 0, i, 5, gridPaint);
        }
        
        // draw filled middle square
        canvas.drawRect(2, 2, 3, 3, gridPaint);   
    }
}
