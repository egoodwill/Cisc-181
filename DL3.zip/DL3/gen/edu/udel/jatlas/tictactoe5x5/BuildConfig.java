/** Automatically generated file. DO NOT MODIFY */
package edu.udel.jatlas.tictactoe5x5;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}