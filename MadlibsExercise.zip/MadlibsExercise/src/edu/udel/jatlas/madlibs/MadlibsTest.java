package edu.udel.jatlas.madlibs;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import junit.framework.TestCase;

public class MadlibsTest extends TestCase {
    
    public void test_WordBank() {
        WordBank wbtest = new WordBank();
        wbtest.addWord("noun", "bee");
        assertEquals(Arrays.asList("bee"), wbtest.getBank().get("noun"));
        
        wbtest.addWord("noun", "hive");
        assertEquals(Arrays.asList("bee", "hive"), wbtest.getBank().get("noun"));
        
        String chosen = wbtest.chooseWord("noun1");
        assertTrue("bee".equals(chosen) || "hive".equals(chosen));
    }
    
    public void test_Madlib() throws Exception {
        Madlib mtest = new Madlib();
        String s = "A _noun1_ _verb1_s into a _verb2_ing car.";
        mtest.readFrom(new ByteArrayInputStream(s.getBytes()));
        
        Set<String> fromString = new HashSet<String>(Arrays.asList(mtest.getKeyWords()));
        assertEquals(new HashSet<String>(Arrays.asList("noun1","verb1","verb2")), fromString);
        
        WordBank wbtest = new WordBank();
        wbtest.addWord("noun", "bee");
        wbtest.addWord("verb", "jump");
        wbtest.addWord("verb", "twirl");
        
        mtest.assignWords(wbtest);
        StringBuilder sb = new StringBuilder();
        mtest.parse(new ByteArrayInputStream(s.getBytes()), sb);
        String result = sb.toString();
        assertTrue(result.equals("A bee jumps into a twirling car.") ||
            result.equals("A bee twirls into a jumping car."));
    }
    
    public void test_ExampleMadlib() throws Exception {
        Madlib madlib = new Madlib();
        madlib.readFrom(new FileInputStream("./assets/stories/Buzz_Lightyear.txt"));
        
        WordBank wordBank = new WordBank();
        wordBank.readFrom(new FileInputStream("./assets/wordbanks/default.txt"));
        
        Set<String> fromFile = new HashSet<String>(Arrays.asList(madlib.getKeyWords()));
        assertEquals(new HashSet<String>(Arrays.asList("noun1","adjective",
            "verb past tense","noun2","noun3","proper noun")), fromFile);
        
        assertEquals(Arrays.asList("Andre", "Neil Patrick Harris", "Prof Dumbledore"), wordBank.getBank().get("name"));
        madlib.assignWords(wordBank);
        
        for (Map.Entry<String, String> entry : madlib.getWords().entrySet()) {
            assertNotNull(entry.getValue());
            assertTrue(!"".equals(entry.getValue()));
        }
        
        StringBuilder sb = new StringBuilder();
        madlib.parse(new FileInputStream("./assets/stories/Buzz_Lightyear.txt"), sb);
        
        assertTrue(sb.indexOf("_") < 0);
        assertTrue(sb.indexOf("noun") < 0);
    }
}
