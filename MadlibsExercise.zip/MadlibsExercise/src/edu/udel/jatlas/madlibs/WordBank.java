package edu.udel.jatlas.madlibs;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class WordBank {
    private Map<String, List<String>> bank;
    private Random r;

    public WordBank() {
        bank = new HashMap<String, List<String>>();
        r = new Random();
    }
    
    public void readFrom(InputStream in) throws IOException {
        Scanner input = new Scanner(in);
        while (input.hasNext()) {
            String line = input.nextLine();
            String[] keyvalues = line.split("=");            
            String[] items = keyvalues[1].split(",");

            // trim the extra space off each item
            for (int i = 0; i < items.length; i++) {
                // need some code here
            }
            
            // create a list of strings with all of the items and put it in the map with the key of the part of speech
        }
    }
    
    public String chooseWord(String key) {
        // key could be something like noun2, we need to change it to "noun" first
        String word = key.replaceAll("[0-9]", "");
        
        // get a word from the bank and remove one of the choices and then return the choice
        return null;
    }
    
    public void addWord(String key, String word) {
        // check to see if the bank has a list of words already for the key, 
        // if not create an empty list and put it in the map
        
        // then add the given word to the list
    }
    
    public Map<String, List<String>> getBank() {
        return bank;
    }
}
