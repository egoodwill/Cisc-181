package edu.udel.jatlas.madlibs;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Madlib {
    private Map<String, String> words;
    
    public Madlib() {
        this.words = new HashMap<String, String>();
    }
    
    public void readFrom(InputStream in) throws IOException {
        Scanner input = new Scanner(in);
        input.useDelimiter("\\_");
        // our words should map the _type_
        while (input.hasNext()) {
            String s = input.next();
                
            // right now this will put everything into the map
            // but we only want the words that were surrounded by _
            words.put(s, "");
            
            // HINT: see the parse method below that does the last step of the whole game
           
        }
    }
    
    public Map<String, String> getWords() {
        return words;
    }

    public String[] getKeyWords() {
        // return the keys that are in the words Map as a String[] in alphabetical order
        
        return null;
    }
    
    public void assignWords(WordBank bank) {
        // for each key in the words keyset, choose a word from the wordbank and assign it to the key in the words map
        for (String key : words.keySet()) {
            
        }
    }
    
    
    public void parse(InputStream in, Appendable out) throws IOException {
        Scanner input = new Scanner(in);
        input.useDelimiter("\\_");
        // our words should map the _type_
        boolean realText = true;
        while (input.hasNext()) {
            String s = input.next();
            // assume first thing is real text, so every other one is a word to replace
            out.append(realText ? s : words.get(s));
            
            realText = !realText;
        }
    }
    
    public static void main(String[] args) throws IOException {
        Madlib m = new Madlib();
        m.readFrom(new FileInputStream("./assets/stories/Buzz_Lightyear.txt"));
        
        WordBank b = new WordBank();
        b.readFrom(new FileInputStream("./assets/wordbanks/default.txt"));
        
        m.assignWords(b);
        StringBuilder sb = new StringBuilder();
        m.parse(new FileInputStream("./assets/stories/Buzz_Lightyear.txt"), sb);
        System.out.println(sb.toString());
    }
}
