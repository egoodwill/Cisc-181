package edu.udel.jatlas.drawing;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class SceneView extends View {
    private Circle circle;
    private Paint paint;
    
    public SceneView(Context context) {
        super(context);
        
        circle = new Circle(50);
        paint = new Paint();
    }
    
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.BLACK);
        paint.setColor(Color.RED);
        
        canvas.translate(100, 100);
        circle.draw(canvas, paint);
    }

}
