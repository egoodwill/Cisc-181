package edu.udel.jatlas.drawing;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Circle {
	private double radius;
	
	public Circle(double radius) {
		this.radius = radius;
	}
	
	public double getArea() {
		return radius * radius * 3.14159;
	}
	
	public double getRadius() {
		return radius;
	}
	
	public void draw(Canvas canvas, Paint paint) {
	    canvas.drawCircle((float)radius, (float)radius, (float)radius, paint);
	}
	
	public static double getArea(double radius) {
		return radius * radius * 3.14159;
	}
}
