package edu.udel.jatlas.tictactoe5x5;

public class BlockedPiece extends Piece {
    public BlockedPiece() {
        super('#');
    }
}
