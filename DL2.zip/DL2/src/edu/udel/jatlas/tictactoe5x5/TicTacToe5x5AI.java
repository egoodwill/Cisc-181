package edu.udel.jatlas.tictactoe5x5;


import java.util.ArrayList;
import java.util.List;

import edu.udel.jatlas.gameframework.AI;
import edu.udel.jatlas.gameframework.Action;

public class TicTacToe5x5AI extends AI<TicTacToe5x5Game> {
    public TicTacToe5x5AI(String symbol) {
        super(symbol);
    }
    
    // convenience method
    private char getOurSymbol() {
        return getIdentifier().charAt(0);
    }
    
    protected boolean isMyTurn(TicTacToe5x5Game game) {
        return game.getTurn() == getOurSymbol();
    }

    /**
     * Get all possible valid actions for the TicTacToe game.
     * 
     * @param game
     * @return
     */
    public List<Action<TicTacToe5x5Game>> getAllValidActions(TicTacToe5x5Game game) {
        List<Action<TicTacToe5x5Game>> validMoves = new ArrayList<Action<TicTacToe5x5Game>>();
        // prevent the AI from taking a turn the same tick as the other player
        if (game.getLastActionTickId() != game.getTickId()) {
        	for(int i = 0; i < game.getBoard().length; i++){
        		for(int j = 0; j < game.getBoard().length; j++){
        			if(game.getBoard()[i][j].getSymbol() == ' '){
        				PlacePieceAction x = new PlacePieceAction(game.getTurn(), i, j);
        				validMoves.add(x);
        			}
        		}
        	}
        }
        
        return validMoves;
    }

    /**
     * Uses a simple heuristic that computes the score for this AI player
     * if the AI was to perform the given action.
     */
    public double getHeuristicScore(Action<TicTacToe5x5Game> action, TicTacToe5x5Game game) {
    	action.update(game);
    	int heuristicScore = game.getScore(getOurSymbol());
    	game.setPiece(((PlacePieceAction)action).getRow(), ((PlacePieceAction)action).getColumn(), new EmptyPiece());
    	game.changeTurn();
        return heuristicScore;
    }
}
