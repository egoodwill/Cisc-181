
// Eric Goodwill and Boli Hua
package edu.udel.jatlas.tictactoe5x5;


import edu.udel.jatlas.gameframework.ConsoleListener;
import edu.udel.jatlas.gameframework.Game;
import edu.udel.jatlas.gameframework.JavaTicker;

/**
 * A basic TicTacToe game model that has been modified to allow
 * play on a 5x5 board where the winner must get 4 in a row.
 * In addition, pieces may be specified to be empty, x, o, or
 * blocked (neither player can place a piece there).
 * 
 * @author jatlas
 */
public class TicTacToe5x5Game extends Game {
    private Piece[][] board;
    private char turn;
    private char notTurn;
    
    
    public TicTacToe5x5Game(Piece[][] board, char turn, char notTurn) {
        this.board = board;
        this.turn = turn;
        this.notTurn = notTurn;
    }

    public Piece[][] getBoard() {
        return board;
    }

    public char getTurn() {
        return turn;
    }

    public char getNotTurn() {
        return notTurn;
    }
    
    /**
     * Swaps the current turn with the notTurn
     */
    public void changeTurn() { 
    	char newturn = turn;
    	turn = notTurn;
    	notTurn = newturn;
   	}
    
    /**
     * A simple setter for board at a row, column
     */
    public void setPiece(int row, int column, Piece player) {
        board[row][column] = player;
    }
    
    public String getStatus() {
        if (isEnd()) {
            if (isWinner(getTurn())) {
                return "Player " + getTurn() + " wins!";
            }
            else if (isWinner(getNotTurn())) {
                return "Player " + getNotTurn() + " wins!";
            }
            else {
                return "It is a draw.";
            }
        }
        else {
            return "Player " + turn + "'s turn";
        }
    }
    
    /**
     * Returns a "visual" representation of a TicTacToe5x5 board
     */
    public String toString() {
        StringBuilder buffer = new StringBuilder();
        buffer.append(getStatus()+"\n");
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                buffer.append(board[i][j]);
            }
            buffer.append("\n");
        }
        return buffer.toString();
    }
    
    /**
     * Checkes to see if the row and column are within the bounds of
     * the board.
     * 
     * @param row
     * @param column
     * @return
     */
    public boolean isWithinBounds(int row, int column) {
        return row >= 0 && column >= 0 && 
                row < getBoard().length && 
                column < getBoard()[row].length;
    }
        
    /**
     * Gets the maximum sequential times that the given symbol appears
     * on a Piece in the board. Starts at row, column and iterates by
     * dr, dc each loop iteration as long as row, column are within
     * bounds. 
     */
    public int getMaxSequence(int row, int column, int dr, int dc, char symbol) {
        int maxSequence = 0;
        int maxSequence2 = 0;
        while(isWithinBounds(row, column)){
        	if(board[row][column].getSymbol() == symbol){
        		maxSequence2 ++;
        	}
        	else{
        		maxSequence = Math.max(maxSequence, maxSequence2);
        		maxSequence2 = 0;
        	}
        	row += dr;
        	column += dc;
        }
        maxSequence = Math.max(maxSequence, maxSequence2);
        return maxSequence;
    	}
    /**
     * Gets the score for the given symbol in the board. The score is
     * the max value from all results returned from calling getMaxSequence
     * for each unique left-to-right, top-to-bottom, down-right-diagonal, 
     * and down-left-diagonal path.
     */
    public int getScore(char symbol) {
    	int maxScore = 0;
		for(int i = 0; i < board.length; i++){
			maxScore = Math.max(maxScore, getMaxSequence(i, 0, 0, 1, symbol));
			maxScore = Math.max(maxScore, getMaxSequence(0, i, 1, 0, symbol));
			maxScore = Math.max(maxScore, getMaxSequence(0, i, 1, 1, symbol));
			maxScore = Math.max(maxScore, getMaxSequence(i, 0, 1, 1, symbol));
			maxScore = Math.max(maxScore, getMaxSequence(0, i, 1, -1, symbol));
			maxScore = Math.max(maxScore, getMaxSequence(i, 4, 1, -1, symbol));
		}
		return maxScore;
	}
    
    /**
     * Checks to see if the player represented by the given symbol is
     * a winner.
     * 
     * @param symbol
     * @return
     */
    public boolean isWinner(char symbol) {
        return getScore(symbol) >= 4;
    }
    
    /**
     * Returns true if there is any empty space in the board.
     * Uses the isEmpty() method on Piece.
     * 
     * @return
     */
    public boolean hasEmptySpace() {
    	for(int i = 0; i<board.length;i++){	
        	for(int j = 0; j<board[i].length;j++){
        		if(board[i][j].getSymbol() == ' '){
        			return true;
        		}
        	}
        }
        return false;
    }
    
    /**
     * Determines if the game is at an end state (i.e. no further moves can be
     * made). For TicTacToe this method returns true if there are no empty
     * spaces on the board or if either player has won.
     * 
     * @return
     */
    public boolean isEnd() {
        return !hasEmptySpace() || isWinner(turn) || isWinner(notTurn);
    }
    
    public static TicTacToe5x5Game makeStartGame(char turn, char notTurn) {
        // creates a starting board
        Piece E = new EmptyPiece();
        Piece B = new BlockedPiece();
        
        Piece[][] board = new Piece[][]
                {{E, E, E, E, E},
                 {E, E, E, E, E},
                 {E, E, B, E, E},
                 {E, E, E, E, E},
                 {E, E, E, E, E}};
        return new TicTacToe5x5Game(board, turn, notTurn);
    }
    
    public static void main(String[] args) {
        TicTacToe5x5Game game = makeStartGame('x', 'o');
        game.addGameListener(new ConsoleListener());
        game.addGameListener(new TicTacToe5x5AI("x"));
        game.addGameListener(new TicTacToe5x5AI("o"));
        // uncomment the below line to see the game run "instantly"
        // game.setRealTimeTickLength(0);
        game.start(new JavaTicker());
    }
}
