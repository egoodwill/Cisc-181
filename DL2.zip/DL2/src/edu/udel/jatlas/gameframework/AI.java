package edu.udel.jatlas.gameframework;

import java.util.ArrayList;
import java.util.List;

public abstract class AI<G extends Game> implements GameListener<G> {
    private String identifier;
    
    public AI(String identifier) {
        this.identifier = identifier;
    }
    
    public String getIdentifier() {
        return identifier;
    }
    
    public String toString() {
        return getIdentifier();
    }
    
    public void onEndEvent(G game) {
    }
    
    /**
     * Subclass may override this, but AI does not need to
     * handle this event
     */
    public void onEvent(String event, G game) {
    }
    
    /**
     * 1. Check if it is "my" turn (always the case in a single player game)
     * 2. Perform the best action
     */
    protected void takeTurnIfMyTurn(G game) {
        if (isMyTurn(game)) {
            performBestAction(game);
        }
    }

    public void onStartEvent(G game) {
    }

    public void onPerformActionEvent(Action<G> action, G game) {
    }
    
    /**
     * Subclasses should override if they are multi-player games.
     */
    protected boolean isMyTurn(G game) {
        // for one player games this is fine, it is always our turn
        return true;
    }
    
    /**
     * The AI will try to find its best action
     * to perform this tick and perform that action on the game.
     */
    public void onTickEvent(G game) {
        takeTurnIfMyTurn(game);
    }
    
    protected void performBestAction(G game) {
        Action<G> action = getBestAction(game);
        // in a turn based game the AI might have no best action (since
        //  no actions would be valid when it is not its turn)
        if (action != null) {
            game.perform(action);
        }
    }

    /**
     * getBestAction uses a greedy algorithm to choose the best possible action.
     * Steps:
     * 
     *  1. Get a list of all valid actions.
     *  2. Initialize max score to Double.NEGATIVE_INFINITY and possible actions to an empty list.
     *  3. For each valid action:
     *     1) Get the heuristic score for the action.
     *     2) If score > max score, set max score to score and clear possible action list.
     *     3) If score >= max score, add action to possible action list.
     *  4. Randomly choose an action from the list of possible moves.
     *  
     * @param game
     * @return
     */
    public Action<G> getBestAction(G game) {
    	List<Action<G>> validActions = getAllValidActions(game);
		List<Action<G>> possibleActions = new ArrayList<Action<G>>();
		int maxScore= 0;
		int j = 0;
		for (int i = 0; i < validActions.size()-1; i++){
			if(getHeuristicScore(validActions.get(i),game) == maxScore){
				possibleActions.add(j, validActions.get(i));
				j++;
			}
			if(getHeuristicScore(validActions.get(i),game) > maxScore){
				j = 0;
				possibleActions = new ArrayList<Action<G>>();
				maxScore = (int) Math.max(maxScore,	getHeuristicScore(validActions.get(i), game));
				possibleActions.add(j, validActions.get(i));
			}
		}
		return possibleActions.get(j);
    }
    
    /**
     * Get all possible valid actions for the game.
     * 
     * @param game
     * @return
     */
    public abstract List<Action<G>> getAllValidActions(G game);

    /**
     * AI subclasses need to implement a heuristic that gives a larger
     * number for "better" actions given the game state.
     */
    public abstract double getHeuristicScore(Action<G> action, G game);
}
