package edu.udel.jatlas.drawing;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Circle {
    private float x;
    private float y;
    
	private double radius;
	
	public Circle(double radius) {
		this.radius = radius;
	}
	
	public void setPosition(float x, float y) {
	    this.x = x;
	    this.y = y;
	}
	
	public double getArea() {
		return radius * radius * 3.14159;
	}
	
	public double getRadius() {
		return radius;
	}
	
	public void draw(Canvas canvas, Paint paint) {
	    canvas.translate(x, y);
	    canvas.drawCircle(0, 0, (float)radius, paint);
	}
	
	public static double getArea(double radius) {
		return radius * radius * 3.14159;
	}
}
