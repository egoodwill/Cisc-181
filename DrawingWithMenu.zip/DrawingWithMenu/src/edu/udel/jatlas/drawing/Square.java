package edu.udel.jatlas.drawing;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Square {
    private double sideLength;

    public Square(double sideLength) {
        super();
        this.sideLength = sideLength;
    }
    
    public void draw(Canvas canvas, Paint paint) {
        canvas.drawRect(0, 0, (float)sideLength, (float)sideLength, paint);
    }
}
