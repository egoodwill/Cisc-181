package edu.udel.jatlas.drawing;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

public class SceneView extends View {
    private Circle circle;
    private Square square;
    private Paint paint;
    
    public SceneView(Context context) {
        super(context);
        
        circle = new Circle(50);
        square = new Flower(150, 10);
        paint = new Paint();
        paint.setColor(Color.RED);
    }
    
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.BLACK);
//        canvas.translate(200, 400);

//        paint.setStyle(Paint.Style.STROKE);
//        paint.setStrokeWidth(5);
//        paint.setColor(Color.WHITE);
//        square.draw(canvas, paint);

        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        circle.draw(canvas, paint);
        
    }
    
    public void setColor(int color) {
        paint.setColor(color);
    }
    
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN ||
                event.getAction() == MotionEvent.ACTION_MOVE) {
            circle.setPosition(event.getX(), event.getY());
            invalidate();
        }
        
        return true;
    }

}
