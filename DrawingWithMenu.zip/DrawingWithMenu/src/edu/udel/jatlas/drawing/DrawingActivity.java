package edu.udel.jatlas.drawing;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class DrawingActivity extends Activity {
    SceneView ourView;
    
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        ourView = new SceneView(this);
        setContentView(ourView);
    }
    
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Blue");
        menu.add("Red");
        return true;
    }
    
    public boolean onOptionsItemSelected(MenuItem item) {
        String value = item.getTitle().toString();
        if (value.equals("Blue")) { 
            ourView.setColor(Color.BLUE);
        }
        else if (value.equals("Red")) { 
            ourView.setColor(Color.RED);
        }
        ourView.invalidate();
        return true;
    }
}
