package edu.udel.jatlas.drawing;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Flower extends Square {
    private int petals;

    public Flower(double sideLength, int petals) {
        super(sideLength);
        this.petals = petals;
    }
    
    public void draw(Canvas canvas, Paint paint) {
        canvas.save();
        
        for (int i = 0; i < petals; i++) {
            canvas.rotate(360 / petals);
            super.draw(canvas, paint);
        }
        
        canvas.restore();
    }
}
