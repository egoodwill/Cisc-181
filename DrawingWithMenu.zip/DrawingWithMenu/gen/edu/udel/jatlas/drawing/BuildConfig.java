/** Automatically generated file. DO NOT MODIFY */
package edu.udel.jatlas.drawing;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}