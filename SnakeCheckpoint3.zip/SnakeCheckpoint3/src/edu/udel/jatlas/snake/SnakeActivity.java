package edu.udel.jatlas.snake;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;
import edu.udel.jatlas.gameframework.Action;
import edu.udel.jatlas.gameframework.Game;
import edu.udel.jatlas.gameframework.GameListener;
import edu.udel.jatlas.gameframework.android.AndroidTicker;

public class SnakeActivity extends Activity implements GameListener<SnakeGame> {
    public static final int GAMETYPE_AI = 0;
    public static final int GAMETYPE_HUMAN = 1;

    private TextView status;
    private SnakeView gameView;
    private SnakeGame game;
    
    private int gameType;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        status = new TextView(this);
        gameView = new SnakeView(this);
        
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.addView(status);
        ll.addView(gameView);
        
        startGame();

        setContentView(ll);
    }
    
    public SnakeGame getCurrentGame() {
        return game;
    }
    
    public int getGameType() {
        return gameType;
    }
    
    public void startGame() {
        // make game visible
        
        game = SnakeGame.makeDefaultStartGame();
        game.addGameListener(this);

        if (gameType == GAMETYPE_AI) {
            game.addGameListener(new SnakeAI());
        }
        
        game.start(new AndroidTicker());
        SnakeHuman human = new SnakeHuman(this);
        gameView.setOnTouchListener(human);
        gameView.setOnKeyListener(human);
    }
    
    public void restartGame() {
        if (game != null && game.getLifecycle() != Game.ENDED) {
            game.end();
        }
        startGame();
    }
    
    @Override
    public void onPerformActionEvent(Action<SnakeGame> action, SnakeGame game) {
        updateViews();
    }

    @Override
    public void onTickEvent(SnakeGame game) {
        updateViews();
    }

    @Override
    public void onStartEvent(SnakeGame game) {
        updateViews();
    }

    @Override
    public void onEndEvent(SnakeGame game) {
        updateViews();
    }

    @Override
    public void onEvent(String event, SnakeGame game) {
        updateViews();
    }
    
    private void updateViews() {
        gameView.invalidate();
        status.setText(game.getStatus());
    }

    
    public boolean onCreateOptionsMenu(Menu menu){
        menu.add("Demo");
        menu.add("Play Game");
        menu.add("Restart");
        menu.add("Quit");
        return true;
    }
    
    public boolean onOptionsItemSelected(MenuItem item) {
        CharSequence title = item.getTitle();
        if (title.equals("Demo")) {
            gameType = GAMETYPE_AI;
            restartGame();
        }
        else if (title.equals("Play Game")) {
            gameType = GAMETYPE_HUMAN;
            restartGame();
        }
        else if (title.equals("Restart")) {
            // start a new game with the same players as previous game
            restartGame();
        }
        else if (title.equals("Quit")) {
            finish();
        }
        return true;
    }
    
    
}
