package edu.udel.jatlas.snake;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.RectF;
import android.view.View;
import edu.udel.jatlas.gameframework.Position;

public class SnakeView extends View {
    // the activity
    protected SnakeActivity activity;
    
    // the loaded bitmaps of images used to draw the game
    private Bitmap foodImage;
    private Bitmap headUDImage;
    private Bitmap headLRImage;
    private Bitmap bodyImage;
    private Bitmap wallImage;
        
    public SnakeView(SnakeActivity context) {
        super(context);
        activity = context;
        
        setBackgroundColor(Color.BLACK);
        
        setFocusable(true);
        setFocusableInTouchMode(true);
        foodImage = loadImage("food");
        headUDImage = loadImage("head_ud");
        headLRImage = loadImage("head_lr");
        bodyImage = loadImage("body");
        wallImage = loadImage("wall");
    }
    
    /**
     * Helper method so we don't have to write this code as much
     */
    private Bitmap loadImage(String name) {
        return BitmapFactory.decodeResource(activity.getResources(), 
            activity.getResources().getIdentifier(name, "drawable", getClass().getPackage().getName()));
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        
        canvas.save();
        canvas.scale(
            getWidth() / (float)SnakeGame.SNAKE_WORLD_WIDTH, 
            getHeight() / (float)SnakeGame.SNAKE_WORLD_HEIGHT);
        
        // draw the walls first
        drawWalls(canvas);
        
        // draw the food
        drawFood(canvas);
        
        // draw the snake
        drawSnake(canvas);
        
        canvas.restore();
    }
        
    // for performance only
    RectF rectF = new RectF();
    private void setRectFromPosition(Position position) {
        rectF.set(position.getColumn(), position.getRow(), position.getColumn()+1f, position.getRow()+1f);
    }
    
    public void drawWalls(Canvas canvas) {
        for (Wall wall : activity.getCurrentGame().getWalls()) {
            for (Position p : wall) {
                setRectFromPosition(p);
                canvas.drawBitmap(wallImage, null, rectF, null);
            }
        }
    }
    
    public void drawFood(Canvas canvas) {
        Food food = activity.getCurrentGame().getFood();
        setRectFromPosition(food.getPosition());
        canvas.drawBitmap(foodImage, null, rectF, null);
    }
    
    public void drawSnake(Canvas canvas) {
        Snake snake = activity.getCurrentGame().getSnake();
        
        Bitmap image = 
            snake.getDirection() == Snake.DIRECTION_DOWN || 
            snake.getDirection() == Snake.DIRECTION_UP ? headUDImage : headLRImage;
        
        boolean head = true;
        
        for (Position position : snake.getSegments()) {
            setRectFromPosition(position);
            
            canvas.drawBitmap(image, null, rectF, null);
            if (head) {
                image = bodyImage;
                head = false;
            }
        }
    }
}
