package edu.udel.jatlas.snake;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;
import edu.udel.jatlas.gameframework.Action;
import edu.udel.jatlas.gameframework.Position;

public class SnakeTests extends TestCase {
    // START -- these are factory methods that create test game states
    public static SnakeGame createStartGame() {
        return SnakeGame.makeDefaultStartGame();
    }
    
    
    public static SnakeGame createMidGame() {
        Snake snake = new Snake(new LinkedList<Position>(Arrays.asList(
            new Position(3, 2), new Position(3, 3))), Snake.DIRECTION_UP); 
        List<Wall> walls = SnakeGame.makeStartWalls();
        Food food = new Food(new Position(2, 2));
        return SnakeGame.makeStartGame(food, snake, walls);
    }
        
    public static SnakeGame createMidGame2() {
        Snake snake = new Snake(new LinkedList<Position>(Arrays.asList(
            new Position(5, 5), new Position(5, 6))), Snake.DIRECTION_LEFT); 
        List<Wall> walls = SnakeGame.makeStartWalls();
        Food food = new Food(new Position(2, 2));
        return SnakeGame.makeStartGame(food, snake, walls);
    }
    
    public static SnakeGame createAlmostEndGameWall() {
        Snake snake = new Snake(new LinkedList<Position>(Arrays.asList(
            new Position(3, 1), new Position(3, 2))), Snake.DIRECTION_UP); 
        List<Wall> walls = SnakeGame.makeStartWalls();
        Food food = new Food(new Position(2, 2));
        return SnakeGame.makeStartGame(food, snake, walls);
    }
    
    public static SnakeGame createEndGameWall() {
        Snake snake = new Snake(new LinkedList<Position>(Arrays.asList(
            new Position(3, 0), new Position(3, 1))), Snake.DIRECTION_UP);
        List<Wall> walls = SnakeGame.makeStartWalls();
        Food food = new Food(new Position(2, 2));
        return SnakeGame.makeStartGame(food, snake, walls);
    }
    
    public static SnakeGame createEndGameOverlap() {
        Snake snake = new Snake(new LinkedList<Position>(Arrays.asList(
            new Position(3, 3), new Position(3, 4), 
            new Position(4, 4), new Position(4, 3),
            new Position(3, 3))), Snake.DIRECTION_UP);
        List<Wall> walls = SnakeGame.makeStartWalls();
        Food food = new Food(new Position(2, 2));
        return SnakeGame.makeStartGame(food, snake, walls);
    }
    
    // END -- factory methods
    
    
    // START -- actual tests now
    
    public void test_isEnd() {
        assertFalse(createStartGame().isEnd());
        assertTrue(createEndGameWall().isEnd());
        assertTrue(createEndGameOverlap().isEnd());
    }
    
    
    public void test_getHeuristic() {
        SnakeAI ai = new SnakeAI();
       
        ChangeDirectionMove up = new ChangeDirectionMove(Snake.DIRECTION_UP);
        ChangeDirectionMove down = new ChangeDirectionMove(Snake.DIRECTION_DOWN);
        ChangeDirectionMove right = new ChangeDirectionMove(Snake.DIRECTION_RIGHT);
        ChangeDirectionMove left = new ChangeDirectionMove(Snake.DIRECTION_LEFT);

        // snake would hit the wall if it went up again
        assertEquals(0.0, ai.getHeuristicScore(up, createAlmostEndGameWall()));
        // snake would hit its own segment if it went down
        assertEquals(0.0, ai.getHeuristicScore(down, createAlmostEndGameWall()));
        // it would be okay to go right
        assertEquals(37.0, ai.getHeuristicScore(right, createAlmostEndGameWall()));
        
        assertEquals(40.0, ai.getHeuristicScore(left, createMidGame())); // close to food, facing it (would eat it next tick)
        assertEquals(38.0, ai.getHeuristicScore(right, createMidGame())); // close to food, not facing it
        assertEquals(35.0, ai.getHeuristicScore(up, createMidGame2())); // now farther away from food
    }
    
    public void test_ChangeDirectionMove() {
        ChangeDirectionMove up = new ChangeDirectionMove(Snake.DIRECTION_UP);
        ChangeDirectionMove down = new ChangeDirectionMove(Snake.DIRECTION_DOWN);
        ChangeDirectionMove left = new ChangeDirectionMove(Snake.DIRECTION_LEFT);
        ChangeDirectionMove right = new ChangeDirectionMove(Snake.DIRECTION_RIGHT);
        // all of the moves should be valid for all states
        assertTrue(up.isValid(createStartGame()));
        assertTrue(down.isValid(createStartGame()));
        assertTrue(left.isValid(createStartGame()));
        assertTrue(right.isValid(createStartGame()));

        assertTrue(up.isValid(createMidGame()));
        assertTrue(down.isValid(createMidGame()));
        assertTrue(left.isValid(createMidGame()));
        assertTrue(right.isValid(createMidGame()));
        
        SnakeGame game = createMidGame();
        game.perform(up);
        assertEquals(Snake.DIRECTION_UP, game.getSnake().getDirection());
        game.perform(down);
        assertEquals(Snake.DIRECTION_DOWN, game.getSnake().getDirection());
        game.perform(left);
        assertEquals(Snake.DIRECTION_LEFT, game.getSnake().getDirection());
        game.perform(right);
        assertEquals(Snake.DIRECTION_RIGHT, game.getSnake().getDirection());
    }
    
    public void test_Snake_OnTick() {
        SnakeGame game = createMidGame();
        Snake snake = game.getSnake();
        snake.onTick(game);
        assertTrue(snake.getSegments().containsAll(Arrays.asList(new Position(3, 1), new Position(3, 2))));

        snake.setDirection(Snake.DIRECTION_LEFT);
        snake.onTick(game);
        assertTrue(snake.getSegments().containsAll(Arrays.asList(new Position(2, 1), new Position(3, 1))));
        
        snake.setDirection(Snake.DIRECTION_DOWN);
        snake.onTick(game);
        assertTrue(snake.getSegments().containsAll(Arrays.asList(new Position(2, 2), new Position(2, 1))));

        snake.setDirection(Snake.DIRECTION_RIGHT);
        snake.onTick(game);
        assertTrue(snake.getSegments().containsAll(Arrays.asList(new Position(3, 2), new Position(2, 2))));

    }
    
    public void test_OnTick() {
        SnakeGame game = createMidGame();
        game.getSnake().setDirection(Snake.DIRECTION_LEFT);
        // okay game has a snake with 2 segment that is about
        // to eat the food and a current score of 0
        game.onTick();
        // now test things that should happen
        assertEquals(1, game.getSnake().getGrowOnNextTick()); // snake should grow
        assertEquals(1, game.getScore()); // score go up by 1
        assertTrue(game.getFood().getPosition().blockDistance(
            game.getSnake().getSegments().getFirst()) > 0); // food should not spawn on snake head
    }
    
    public void test_GameLevel() {
        SnakeGame game = createMidGame();
        Snake snake = new Snake(new LinkedList<Position>(Arrays.asList(
            new Position(3, 2),
            new Position(4, 2),
            new Position(5, 2),
            new Position(5, 3),
            new Position(4, 3),
            new Position(3, 3),
            new Position(2, 3),
            new Position(1, 3),
            new Position(1, 4),
            new Position(2, 4),
            new Position(3, 4),
            new Position(4, 4),
            new Position(5, 4))), Snake.DIRECTION_LEFT); // a winded up snake of len=13 that is about to eat food
        game.setSnake(snake);
        
        assertEquals(0, game.getLevel());
        game.onTick();
        // ok now the game should be on the next level
        assertEquals(1, game.getLevel()); // level up by 1
        assertEquals(1, game.getScore()); // score up by 1
        assertEquals(160, game.getSpeed()); // speed increase by 20%
        assertEquals(SnakeGame.SNAKE_LENGTH_START, game.getSnake().getSegments().size()); // snake shrink back
    }
    
    public void test_AI_getAllValidActions() {
        SnakeGame game = createMidGame();
        SnakeAI ai = new SnakeAI();
        
        List<Action<SnakeGame>> actions = ai.getAllValidActions(game);
        // check to make sure we have all of the directions covered
        // because in snake state createMidGame3 we should be able to change the
        // snake to face any direction
        Set<Integer> directionsPossible = new HashSet<Integer>();
        for (Action<SnakeGame> move : actions) {
            if (move instanceof ChangeDirectionMove) {
                ChangeDirectionMove cmove = (ChangeDirectionMove)move;
                directionsPossible.add(cmove.getDirection());
            }
        }
        assertTrue(directionsPossible.contains(Snake.DIRECTION_DOWN));
        assertTrue(directionsPossible.contains(Snake.DIRECTION_UP));
        assertTrue(directionsPossible.contains(Snake.DIRECTION_LEFT));
        assertTrue(directionsPossible.contains(Snake.DIRECTION_RIGHT));
    }
    
    public void test_AI_getBestAction() {
        SnakeGame game = createMidGame();
        SnakeAI ai = new SnakeAI();
        // check to see if in state 2 they will make the move that will face towards the food

        // test will fail until you finish DL2 and copy the AI class into this project
        ChangeDirectionMove move = (ChangeDirectionMove)ai.getBestAction(game);
        assertEquals(Snake.DIRECTION_LEFT, move.getDirection());
    }
    
    // END -- actual tests
    
    public static void main(String[] args) {
        System.out.println(createStartGame());
        System.out.println(createMidGame());
        System.out.println(createEndGameWall());
        System.out.println(createEndGameOverlap());
        
        
        System.out.println(new ChangeDirectionMove(Snake.DIRECTION_UP));
        System.out.println(new ChangeDirectionMove(Snake.DIRECTION_DOWN));
        System.out.println(new ChangeDirectionMove(Snake.DIRECTION_LEFT));
        System.out.println(new ChangeDirectionMove(Snake.DIRECTION_RIGHT));
    }
}
