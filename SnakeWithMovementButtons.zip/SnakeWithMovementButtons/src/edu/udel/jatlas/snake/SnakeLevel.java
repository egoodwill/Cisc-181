package edu.udel.jatlas.snake;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import edu.udel.jatlas.gameframework.Position;

/**
 * A Snake "level" is really just different walls
 * 
 * @author jatlas
 */
public class SnakeLevel {
    private List<Wall> walls;
    
    
    public SnakeLevel(List<Wall> walls) {
        this.walls = walls;
    }

    /**
     * Mutates the game so that the game now is at the starting
     * state for this level.
     * 
     * @param game
     */
    public void setGameToStartOfLevel(SnakeGame game) {
        game.setWalls(walls);
        Snake snake = SnakeGame.makeStartSnake();
        snake.grow(game.getSnake().getSegments().size()-snake.getSegments().size());
        game.setSnake(snake);
        // reset the food otherwise it could stay inside of a wall!
        game.addRandomFood();
    }
    
    public static SnakeLevel loadFromStream(InputStream stream, int level) {
        Scanner scanner = new Scanner(stream);
        scanner.useDelimiter("\n");
        // format for file:
        // has WORLD_HEIGHT lines
        // each line has WORLD_WIDTH entries
        //   each entry is one of:
        //   'W' is wall, ' ' is empty
        List<Wall> walls = new ArrayList<Wall>();
        for (int row = 0; row < SnakeGame.SNAKE_WORLD_HEIGHT; row++) {
            String line = scanner.next();
            char[] encoded = line.toCharArray();
            for (int i = 0; i < encoded.length; i++) {
                if (encoded[i] == 'W') {
                    // this is somewhat inefficient (it creates a Wall for each W), but will work
                    Position p = new Position(i, row);
                    walls.add(new Wall(p, p));
                }
            }
        }
        return new SnakeLevel(walls);
    }
}
