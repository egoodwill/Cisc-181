package edu.udel.jatlas.snake;

import java.util.ArrayList;
import java.util.List;

import edu.udel.jatlas.gameframework.AI;
import edu.udel.jatlas.gameframework.Action;
import edu.udel.jatlas.gameframework.Position;

/**
 * Snake AI uses a basic heuristic that avoids death and otherwise
 * tries to go towards the food.
 * 
 * @author jatlas
 */
public class SnakeAI extends AI<SnakeGame> {
    // snake is single-player, so the AI's identity does not matter 
    public SnakeAI() {
        super("AI"); 
    }
    
    /**
     * Returns a list of all valid moves from a given state.
     * 
     * @param state
     * @return
     */
    public List<Action<SnakeGame>> getAllValidActions(SnakeGame game) {
        List<Action<SnakeGame>> validMoves = new ArrayList<Action<SnakeGame>>();
        if (!game.isEnd()) {
            // well a valid move is anything in Snake
            // (might not be a *good* move though, as you could die on the next tick)
          validMoves.add(new ChangeDirectionMove(Snake.DIRECTION_DOWN));
          validMoves.add(new ChangeDirectionMove(Snake.DIRECTION_UP));
          validMoves.add(new ChangeDirectionMove(Snake.DIRECTION_RIGHT));
          validMoves.add(new ChangeDirectionMove(Snake.DIRECTION_LEFT));
        }
        return validMoves;
    }

    
    /**
     * To determine the heuristic score of Snake we want to determine
     * how close we are to the food.  However, sometimes we are facing
     * impending doom (which is bad).  Here is a breakdown of scores:
     * 
     * -1 = we already lost (game is at end already)
     * 0 = we are about to lose 
     * maxDistance - currentDistance = how far are we from the food?
     * 
     * Because we can't be farther from the food than rows + columns, we
     * subtract the distance to give us a high score if we are about to eat
     * the food.
     * 
     * @param state
     * @return
     */
    public double getHeuristicScore(Action<SnakeGame> action, SnakeGame game) {
        if (game.isEnd()) {
            return -1;
        }
        // all actions in Snake are ChangeDirectionMove so this is safe
        ChangeDirectionMove m = (ChangeDirectionMove)action;
        
        // would the direction take us towards death?
        Snake snake = game.getSnake();
        Position next = snake.getNextPosition(m.getDirection());
        if (game.isWall(next)) {
            return 0;
        }
        if (snake.getSegments().contains(next)) {
            return 0;
        }
        
        int maxDistance = game.getRows() + game.getCols();
        // ok return a score based on distance from food
        return maxDistance - game.getFood().getPosition().blockDistance(next);
    }
}
