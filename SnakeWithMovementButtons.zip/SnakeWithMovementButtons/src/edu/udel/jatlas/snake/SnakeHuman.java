package edu.udel.jatlas.snake;

import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import edu.udel.jatlas.gameframework.Position;

public class SnakeHuman implements View.OnTouchListener, View.OnKeyListener, View.OnClickListener {
    private SnakeActivity activity;

    public SnakeHuman(SnakeActivity activity) {
        this.activity = activity;
    }

    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getAction();
        SnakeGame game = activity.getCurrentGame();
        if (game != null) {
            // is the game ended? if so restart it!
            if (game.isEnd()) {
                activity.setAppView("Splash");
            }
            else if (activity.getGameType() == SnakeActivity.GAMETYPE_HUMAN
                    && action == MotionEvent.ACTION_DOWN) {
                // where did they click on the board?
                int row = (int)((event.getY() / v.getHeight()) * 
                        game.getRows());
                int col = (int)((event.getX() / v.getWidth()) * 
                        game.getCols());
                
                // which direction does that indicate?
                Position head = game.getSnake().getSegments().getFirst();
                int changeX = col - head.getColumn();
                int changeY = row - head.getRow();
                int direction = game.getSnake().getDirection();
                
                // this conditional prevents the user from going back on itself so that
                //  all input "curls" around
                if ((direction == Snake.DIRECTION_LEFT && (Math.abs(changeY) > Math.abs(changeX)
                        || (Math.abs(changeY) > 0 && changeX > 0)))
                    || (direction == Snake.DIRECTION_RIGHT && (Math.abs(changeY) > Math.abs(changeX)
                        || (Math.abs(changeY) > 0 && changeX < 0)))) {
                    direction = changeY > 0 ? Snake.DIRECTION_DOWN : Snake.DIRECTION_UP;
                }
                else if ((direction == Snake.DIRECTION_UP && (Math.abs(changeX) > Math.abs(changeY)
                        || (Math.abs(changeX) > 0 && changeY > 0)))
                    || (direction == Snake.DIRECTION_DOWN && (Math.abs(changeX) > Math.abs(changeY)
                        || (Math.abs(changeX) > 0 && changeY < 0)))) {
                    // we should move sideways
                    direction = changeX > 0 ? Snake.DIRECTION_RIGHT : Snake.DIRECTION_LEFT;
                }
                
                if (direction != game.getSnake().getDirection()) {
                    game.perform(new ChangeDirectionMove(direction));
                }

            }
        }
        
        // we don't need any more events in this sequence
        return false;
    }
    
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        int direction = activity.getCurrentGame().getSnake().getDirection();
        if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_UP) {
            direction = Snake.DIRECTION_UP;
        }
        else if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_DOWN) {
            direction = Snake.DIRECTION_DOWN;
        }
        else if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_LEFT) {
            direction = Snake.DIRECTION_LEFT;
        }
        else if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_RIGHT) {
            direction = Snake.DIRECTION_RIGHT;
        }
        
        if (direction != activity.getCurrentGame().getSnake().getDirection() &&
                direction != activity.getCurrentGame().getSnake().getOppositeDirection()) {
            activity.getCurrentGame().perform(new ChangeDirectionMove(direction));
        }
        
        return false;
    }
    
    public void onClick(View v) {
        if (v instanceof Button) {
            Button b = (Button)v;
            String text = b.getText().toString();
            int direction = activity.getCurrentGame().getSnake().getDirection();
            if (text.equals("^")) {
                direction = Snake.DIRECTION_UP;
            }
            else if (text.equals("v")) {
                direction = Snake.DIRECTION_DOWN;
            }
            else if (text.equals("<")) {
                direction = Snake.DIRECTION_LEFT;
            }
            else if (text.equals(">")) {
                direction = Snake.DIRECTION_RIGHT;
            }
            
            if (direction != activity.getCurrentGame().getSnake().getDirection() &&
                    direction != activity.getCurrentGame().getSnake().getOppositeDirection()) {
                activity.getCurrentGame().perform(new ChangeDirectionMove(direction));
            }
        }
    }
}
