package edu.udel.jatlas.snake;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import edu.udel.jatlas.gameframework.Action;
import edu.udel.jatlas.gameframework.Game;
import edu.udel.jatlas.gameframework.GameListener;
import edu.udel.jatlas.gameframework.android.AndroidTicker;

public class SnakeActivity extends Activity implements GameListener<SnakeGame> {
    private Map<String, View> appViews;
    
    private TextView status;
    private SnakeView gameView;
    private SnakeGame game;
    
    private List<SnakeLevel> levels;
        
    public static final int GAMETYPE_AI = 0;
    public static final int GAMETYPE_HUMAN = 1;
    
    private int gameType;
    
    private SoundManager soundManager;
    
    private Button[] buttons;
    
    public int getGameType() {
        return gameType;
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appViews = new HashMap<String, View>();
        
        soundManager = new SoundManager(this);
        soundManager.init();
        
        status = new TextView(this);
        gameView = new SnakeView(this);
                
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.addView(status);
        
        // create a row with 4 buttons
        LinearLayout buttonLayout = new LinearLayout(this);
        Button up = new Button(this);
        Button down = new Button(this);
        Button left = new Button(this);
        Button right = new Button(this);
        up.setText("^");
        down.setText("v");
        left.setText("<");
        right.setText(">");
        
        
        buttons = new Button[]{up, down, left, right};
        for (Button b : buttons) {
            b.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT,
                0.25f));
            b.setBackgroundColor(Color.TRANSPARENT);
            b.setTextColor(Color.WHITE);
            buttonLayout.addView(b);    
        }
        
        
        
        // uncomment this code if you want buttons at the bottom (not overlay)
//        ll.addView(gameView);
//        gameView.setLayoutParams(new LinearLayout.LayoutParams(
//            LinearLayout.LayoutParams.MATCH_PARENT,
//            LinearLayout.LayoutParams.MATCH_PARENT,
//            0.2f));
//        ll.addView(buttonLayout);
//        buttonLayout.setLayoutParams(new LinearLayout.LayoutParams(
//            LinearLayout.LayoutParams.MATCH_PARENT,
//            LinearLayout.LayoutParams.MATCH_PARENT,
//            0.8f));
        
        // code to overlay the buttons on top of the game view
        FrameLayout fl = new FrameLayout(this);
        fl.addView(gameView);
        LinearLayout hidden = new LinearLayout(this);
        hidden.setOrientation(LinearLayout.VERTICAL);
        View hiddenView = new View(this);
        hiddenView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT,
            1.0f));
        hidden.addView(hiddenView);
        hidden.addView(buttonLayout);
        buttonLayout.setLayoutParams(new LinearLayout.LayoutParams(
          LinearLayout.LayoutParams.MATCH_PARENT,
          LinearLayout.LayoutParams.MATCH_PARENT,
          0.2f));
        fl.addView(hidden);
        
        ll.addView(fl);
        
        appViews.put("Game", ll);
        appViews.put("Splash", new SplashScreen(this));
        
        loadLevels();
        
        setAppView("Splash");
    }
       
    public void setAppView(String nameOfView) {
        View view = appViews.get(nameOfView);
        setContentView(view);
        view.invalidate();
    }
    
    public SnakeGame getCurrentGame() {
        return game;
    }

    private void loadLevels() {
        try {
            
            String[] files = getAssets().list("levels");
            SnakeLevel[] levelArray = new SnakeLevel[files.length];
            
            for (String levelName : files) {
                // Construct a List of levels from an asset
                InputStream in = getAssets().open("levels/" + levelName);
                
                String withoutExtension = levelName.replaceFirst("\\..*", "");
                String justTheNumber = withoutExtension.replaceAll("\\D", "");
                int level = Integer.parseInt(justTheNumber);
                levelArray[level] = SnakeLevel.loadFromStream(in, level);
            }
            
            levels = Arrays.asList(levelArray);
        }
        catch (IOException e) {
            Log.e("Snake", "IOException", e);
        }
    }

    
    public void startGame() {
        // make game visible
        
        game = SnakeGame.makeDefaultStartGame();
        game.setLevels(levels);
        game.addGameListener(this);

        if (gameType == GAMETYPE_AI) {
            game.addGameListener(new SnakeAI());
        }
        
        game.start(new AndroidTicker());
        SnakeHuman human = new SnakeHuman(this);
        gameView.setOnTouchListener(human);
        gameView.setOnKeyListener(human);
        for (Button button : buttons) {
            button.setOnClickListener(human);
        }
        setAppView("Game");
    }
    
    public void restartGame() {
        if (game != null && game.getLifecycle() != Game.ENDED) {
            game.end();
        }
        startGame();
    }
    
    @Override
    public void onPerformActionEvent(Action<SnakeGame> action, SnakeGame game) {
        updateViews();
    }

    @Override
    public void onTickEvent(SnakeGame game) {
        updateViews();
    }

    @Override
    public void onStartEvent(SnakeGame game) {
        updateViews();
    }

    @Override
    public void onEndEvent(SnakeGame game) {
        updateViews();
    }
    
    @Override
    protected void onStop() {
        super.onStop();
        finish();
        if (game != null) {
            game.end();
        }
    }
  

    @Override
    public void onEvent(String event, SnakeGame game) {
        updateViews();
        
        if (event.equals("eat_food")) {
            soundManager.playSound("Action_Eat_Apple_2");
        }
        else if (event.equals("next_level")) {
            if (game.getLevel() > 0) {
                Toast.makeText(this, "Level " + game.getLevel() + "!", Toast.LENGTH_LONG).show();
            }
        }
    }
    
    public void updateViews() {
        gameView.invalidate();
        status.setText(game.getStatus());
    }

       
    public boolean onOptionsItemSelected(MenuItem item) {
        selectMenuOption(item.getTitle());
        return true;
    }
    
    public void selectMenuOption(CharSequence title) {
        if (title.equals("Demo")) {
            gameType = GAMETYPE_AI;
            restartGame();
        }
        else if (title.equals("Play")) {
            gameType = GAMETYPE_HUMAN;
            restartGame();
        }
        else if (title.equals("Restart")) {
            // start a new game with the same players as previous game
            restartGame();
        }
        else if (title.equals("Quit")) {
            finish();
        }
    }
    
    
}
