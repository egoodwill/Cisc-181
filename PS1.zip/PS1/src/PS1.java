
// Eric Goodwill Lab section 22
public class PS1 {
	// takes in the air temperature and wind speed as decimals and puts them into the windChillTemp
	// equation to determine the temperature with the wind
		public static double windChillTemperature(double airTemp, double windSpeed ){
			double x = Math.pow(windSpeed, 0.16);
			double windChillTemp = 35.74 + 0.6215*airTemp - 35.75*x + 0.4275*airTemp*x;
			return windChillTemp;
		}
	// takes in amount of candy and tea as integers and then checks to see if both candy and tea
	// are above 5, if not the method returns 0. The method then checks to see if either candy or
	// tea is greater than double the other. If so the method returns 2, if not, returns 1.
		public static int teaParty(int tea, int candy){
			if ((tea >= 5) && (candy >= 5)){
				 if ((tea >= candy * 2) || (candy >= tea * 2)){
					return 2;
				 }
				 else{
					 return 1;
				 }
			}
			else{
				return 0;
			}
		}
	// The method takes in the first and second digit and then checks to see if they have to same 
	// number in them. First it checks the 1st digit's right with the 2nd's right, then the 1st's
	// right with the 2nd's left and vise versa.
		public static boolean shareDigit(int digit1, int digit2){
			if (digit1 % 10 == digit2 % 10){
				return true;
			}
			else if(digit1 % 10 == digit2 / 10){
				return true;
			}
			else if(digit1 / 10 == digit2 % 10){
				return true;
			}
			else if(digit1 / 10 == digit2 / 10){
				return true;
			}
			else{
				return false;
			}
		}
	// This method takes the square root of a number and then checks to see if the integer
	// ,closest but smaller than the root, divides evenly into the number. If not the method
	// drops 1 integer down and checks again until the number divides evenly.
		public static int closestFactorToSqrt(int num){
			int x = (int) Math.sqrt(num);
			while (num % x != 0){
				x--;
			}
			return x;
		}
	// This method takes a number and adds all the digits up to see if the number is odd.
	// First the method adds the digits using a loop then divides that number by 2. if the remainder is
	// 0 then the number is even and the method will return false. If the remainder is not 0 then the
	// method will return true.
		public static boolean oddParity(int num){
			int x = 0;
			while (num > 1){
				x = x + (num % 10);
				num = (num / 10);
			}
			if (x % 2 == 0){
				return false;
			}
			else{
				return true;
			}
		}
	// This method takes the 3 rolls of die and runs them through certain rules to determine the score.
	// If there is 2 die that are the same then the score will be 10. If 3 of the same then the score
	// is 20. If no die are the same then the score will be the highest dice number.
		public	static	int	score(int d1, int d2, int d3){
			if(d1 == d2	&&	d2 == d3){
							return	20;
			}
			else if(d1 == d2 || d2 == d3 || d1 == d3){
				return	10;
			}
			else{
				return	Math.max(Math.max(d1, d2), d3);
			}
		}
	// This method takes the number of sides on the dice and assigns a random number between 1 and the
	// side number to each die.
		public static int scoreTurn(int sides){
			int	d = (int)(Math.random()*sides) + 1;
			return d;
		}
	// This method runs the actual die game by using a loop to get 1000000 random scores and adding them
	// together then taking the average of the total scores.
		public static double simulate(int sides){
			int x = 0;
			double y = 0;
			while (x <= 1000000){
				y = y + score(scoreTurn(sides), scoreTurn(sides), scoreTurn(sides));
				x++;
			}
			y = y / 1000000;
			return y;
		}
}
			
			
			
			
		

