package ps5;
import java.util.Comparator;


public class CalorieComparator implements Comparator<Edible> {

    public int compare(Edible arg0, Edible arg1) {
        return Double.compare(arg0.getCalories(), arg1.getCalories());
    }
    
}