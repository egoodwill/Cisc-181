package ps5;

public class Orange extends Fruit implements Edible {
    public Orange(double weight) {
        super("Orange", weight);
    }
    
    public double getCalories() {
        return getWeight() * 5;
    }
}