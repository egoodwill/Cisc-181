package ps5;
public abstract class Fruit {
    private String color;
    private double weight;

    protected Fruit(String color, double weight) {
        this.color = color;
        this.weight = weight;
    }

    public String getColor() {
        return color;
    }

    public double getWeight() {
        return weight;
    }
    
    public boolean equals(Object other) {
        if (other instanceof Fruit) {
            Fruit otherFruit = (Fruit)other;
            return weight == otherFruit.weight && color.equals(otherFruit.color);
        }
        else {
            return false;
        }
    }
    
    public abstract double getCalories();
    
    public String toString() {
        return getClass().getSimpleName();
    }
}