package ps5;

public class Snowberry extends Fruit {

    public Snowberry() {
        super("White", 0.117);
    }

    public double getCalories() {
        return 1;
    }
    
}
