package ps5;

public class NavalOrange extends Orange {

    public NavalOrange(double weight) {
        super(weight);
    }

    public double getCalories() {
        return super.getCalories() * 1.1;
    }

    public String toString() {
        return getWeight() > 50 ? "ReallyBigNavalOrange" : super.toString();
    }

}
