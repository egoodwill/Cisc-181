package ps5;

public interface Edible {
    double getCalories();
}